***********************************************
Johanssons Questions
***********************************************

Thank you for applying for one of our roles. We at Johanssons are also developers just like you, therefore we know a bit about different tech out there 
and would like to ask you a some questions around your knowledge.

You should find the following files in this archive :
example.css
example.html
example.php
readme.txt
your_code_samples/

We have put together a number of questions based around these files in order to give us a basic understanding of your skills.

What you need to do:
- Go through each file and answer as many questions as possible, leave blank the ones you are not sure about. Don't worry if you don't know something we are all learning!
- Throw in a couple of code samples in a folder called 'code_samples'
- Zip up everything and send it back to us.

***********************************************
THANK YOU FOR YOUR TIME AND GOOD LUCK!
***********************************************

