***********************************************
Johanssons 
***********************************************

Thank you for applying for one of our roles. We at Johanssons are also developers just like you, therefore we know a bit about different tech out there and would like to ask you some questions on HTML, CSS and PHP to give us a basic understanding of the level you are at.

You should find the following files in this archive:
example.css
example.html
example.php
readme.txt
code_samples/

What you need to do:
- Go through each file and answer as many questions as possible, leave blank the ones you are not sure about. Don't worry if you don't know something we are all learning!
- Throw in a couple of code samples in a folder called 'code_samples'
- Zip up everything and send it back to us.

***********************************************
THANK YOU FOR YOUR TIME AND GOOD LUCK!
***********************************************

